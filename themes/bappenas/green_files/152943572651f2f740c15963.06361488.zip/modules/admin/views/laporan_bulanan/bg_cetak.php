<script type="text/javascript">window.print();</script>
<?php echo $data_retrieve; ?>
